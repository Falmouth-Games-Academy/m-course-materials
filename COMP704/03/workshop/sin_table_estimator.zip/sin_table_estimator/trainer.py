
from sklearn.model_selection import train_test_split
from sklearn import ensemble
from sklearn.metrics import mean_absolute_error
from sklearn.externals import joblib

from sklearn.linear_model import LinearRegression


import math

import pandas as pd
# make a sine table and load into pandas dataframe
input_data = []
output_data = []

for angle in range (0,360,1):
    input_data.append(angle)
    output_data.append( math.sin( (angle *math.pi)/180.0))

data = {'angle' : input_data
       ,'value' : output_data}

df = pd.DataFrame (data, columns = ['angle','value'])

# Create the X and y arrays
x_input = df['angle'].values
x_input = x_input.reshape(-1, 1)
y_output = df['value'].values

# Split the data set in a training set (25%) and a test set (75%)
x_train, x_test, y_train, y_test = train_test_split(x_input, y_output, test_size=0.75, random_state=0)

# Fit regression model
#model = LinearRegression()

model = ensemble.GradientBoostingRegressor()


print('doing training ...')
model.fit(x_train, y_train)
print('done training ...')

# Save the trained model to a file so we can use it in other programs
joblib.dump(model, 'trained_model.pkl')

# Find the error rate on the training set
mse = mean_absolute_error(y_train, model.predict(x_train))
print("Training Set Mean Absolute Error: %.4f" % mse)

# Find the error rate on the test set
mse = mean_absolute_error(y_test, model.predict(x_test))
print("Test Set Mean Absolute Error: %.4f" % mse)


new_model = joblib.load('trained_model.pkl')

for angle in range(0, 370,30):
    test_data = [[angle]]
    model_value = new_model.predict(test_data)
    actual_value = math.sin( (angle *math.pi)/180.0)

    msg = str(angle)
    msg += ": "
    msg += str(round(model_value[0], 3))
    msg += ' ['
    msg += str(round(actual_value, 3) )
    msg += '] err:'
    msg += str(round(math.fabs(model_value[0] - actual_value), 3))
    print(msg)